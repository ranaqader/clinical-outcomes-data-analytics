-- SQLite-compatible operational KPI queries
SELECT primary_condition, COUNT(*) AS encounters,
ROUND(AVG(30_day_readmission)*100,2) AS readmission_rate_pct
FROM synthetic_encounters GROUP BY primary_condition ORDER BY readmission_rate_pct DESC;

SELECT followup_status, COUNT(*) AS encounters,
ROUND(AVG(30_day_readmission)*100,2) AS readmission_rate_pct
FROM synthetic_encounters GROUP BY followup_status ORDER BY readmission_rate_pct DESC;

SELECT discharge_disposition, COUNT(*) AS encounters,
ROUND(AVG(length_of_stay_days),2) AS avg_los_days,
ROUND(AVG(30_day_readmission)*100,2) AS readmission_rate_pct
FROM synthetic_encounters GROUP BY discharge_disposition ORDER BY readmission_rate_pct DESC;
