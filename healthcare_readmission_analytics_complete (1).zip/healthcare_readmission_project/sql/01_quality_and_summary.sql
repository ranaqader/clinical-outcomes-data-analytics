-- 01_quality_and_summary.sql
-- Synthetic healthcare encounter data; no PHI.

-- 1. Overall readmission KPI
SELECT
    COUNT(*) AS encounters,
    ROUND(AVG(30_day_readmission) * 100, 2) AS readmission_rate_pct,
    ROUND(AVG(length_of_stay_days), 2) AS avg_los_days
FROM synthetic_encounters;

-- 2. Readmission by primary condition
SELECT
    primary_condition,
    COUNT(*) AS encounters,
    ROUND(AVG(30_day_readmission) * 100, 2) AS readmission_rate_pct,
    ROUND(AVG(length_of_stay_days), 2) AS avg_los_days
FROM synthetic_encounters
GROUP BY primary_condition
ORDER BY readmission_rate_pct DESC;

-- 3. Follow-up completion
SELECT
    followup_status,
    COUNT(*) AS encounters,
    ROUND(AVG(30_day_readmission) * 100, 2) AS readmission_rate_pct
FROM synthetic_encounters
GROUP BY followup_status
ORDER BY readmission_rate_pct DESC;

-- 4. Insurance subgroup
SELECT
    insurance,
    COUNT(*) AS encounters,
    ROUND(AVG(30_day_readmission) * 100, 2) AS readmission_rate_pct
FROM synthetic_encounters
GROUP BY insurance
ORDER BY readmission_rate_pct DESC;

-- 5. Data quality checks
SELECT
    COUNT(*) AS rows,
    COUNT(DISTINCT encounter_id) AS unique_encounters,
    SUM(CASE WHEN age IS NULL THEN 1 ELSE 0 END) AS missing_age,
    SUM(CASE WHEN primary_condition IS NULL THEN 1 ELSE 0 END) AS missing_condition,
    SUM(CASE WHEN 30_day_readmission NOT IN (0,1) THEN 1 ELSE 0 END) AS invalid_target
FROM synthetic_encounters;
