import streamlit as st
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parent
df = pd.read_csv(ROOT / "data" / "synthetic_encounters.csv")
metrics = pd.read_csv(ROOT / "reports" / "model_comparison.csv")

st.set_page_config(page_title="Healthcare Readmission Analytics", page_icon="🏥", layout="wide")
st.title("🏥 Healthcare Readmission Analytics")
st.caption("Synthetic-data portfolio dashboard — no PHI")
st.warning("Educational demonstration only. Predictions are not clinically validated and must not be used for patient care.")

c1,c2,c3,c4 = st.columns(4)
c1.metric("Encounters", f"{len(df):,}")
c2.metric("30-Day Readmission", f"{df['30_day_readmission'].mean():.1%}")
c3.metric("Avg. LOS", f"{df['length_of_stay_days'].mean():.1f} days")
c4.metric("Missed Follow-Up", f"{(df['followup_status']=='Missed').mean():.1%}")

st.subheader("Readmission by Primary Condition")
st.bar_chart((df.groupby("primary_condition")["30_day_readmission"].mean()*100).sort_values(ascending=False))
st.subheader("Readmission and Follow-Up")
st.bar_chart((df.groupby("followup_status")["30_day_readmission"].mean()*100).sort_values(ascending=False))
st.subheader("Model Comparison")
m=metrics.copy()
for col in ["ROC-AUC","Accuracy","Precision","Recall","F1"]: m[col]=m[col].round(3)
st.dataframe(m,use_container_width=True,hide_index=True)
st.subheader("Responsible Use")
st.markdown("Use predictions as a prioritization signal for human review. A real deployment would require clinical validation, prospective testing, subgroup auditing, privacy/security controls, calibration, drift monitoring, and governance.")
