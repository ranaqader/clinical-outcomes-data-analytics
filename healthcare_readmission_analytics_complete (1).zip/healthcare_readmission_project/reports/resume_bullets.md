### Healthcare Readmission & Patient Risk Analytics | Python, SQL, Machine Learning
- Built an end-to-end healthcare analytics pipeline using 12,000 synthetic encounter records to investigate 30-day hospital readmission patterns.
- Developed and compared logistic regression, random forest, and gradient-boosting models using ROC-AUC, precision, recall, and F1.
- Designed SQL-based healthcare KPIs and a Streamlit dashboard for readmission, utilization, discharge, and follow-up analysis.
- Audited model recall across demographic and insurance subgroups and translated findings into a human-in-the-loop care-management workflow with privacy, fairness, and governance considerations.
- Published reproducible Python, SQL, Jupyter, SQLite, visualization, and documentation artifacts in a GitHub-ready repository.
