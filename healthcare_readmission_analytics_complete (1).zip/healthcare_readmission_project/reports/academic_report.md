# Predicting 30-Day Hospital Readmission Using Explainable Machine Learning

## Abstract
This project develops an end-to-end healthcare analytics workflow using 12,000 synthetic encounters. It combines data-quality validation, SQL-based KPI analysis, exploratory analysis, supervised machine learning, subgroup auditing, and operational recommendations. The overall synthetic readmission rate was 28.8%; average length of stay was 4.73 days. The best model in this run achieved a ROC-AUC of 0.664. Because the data are synthetic, these results are not clinical evidence.

## Methods
Three approaches were compared: logistic regression, random forest, and gradient boosting. Evaluation included ROC-AUC, precision, recall, F1, and accuracy. Subgroup recall was audited across sex, race/ethnicity, and insurance.

## Results
The highest-readmission condition in this synthetic dataset was **Orthopedics** (30.5%). Follow-up status also showed an association with readmission. These relationships are descriptive and should not be interpreted causally.

## Responsible use
The recommended real-world use case is human-in-the-loop prioritization for care-management outreach rather than autonomous clinical decision-making.

## Limitations
The dataset is synthetic, not externally validated, and not representative of any specific patient population. A real deployment would require clinical validation, governance, privacy/security review, calibration, prospective evaluation, and drift monitoring.
