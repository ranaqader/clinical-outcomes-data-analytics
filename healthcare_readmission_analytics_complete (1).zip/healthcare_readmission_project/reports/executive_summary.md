# Executive Summary

**Question:** Can encounter-level information help prioritize patients for additional post-discharge follow-up?

**Dataset:** 12,000 synthetic encounters; no PHI.

**Overall readmission rate:** 28.8%

**Average LOS:** 4.73 days

**Highest observed condition rate:** Orthopedics (30.5%)

**Best model in this run:** Logistic Regression, ROC-AUC 0.664

## Recommendation
Use a validated risk score as a prioritization signal for human care-management review. Do not automate clinical decisions. Pilot implementation should measure patient outcomes, outreach workload, subgroup performance, and model calibration.
