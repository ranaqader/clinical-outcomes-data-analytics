# MSDS Application Framing

This project connects a healthcare/medical-studies background with quantitative and computational problem-solving. It demonstrates the ability to translate a domain problem into measurable questions, validate data, use SQL, analyze data in Python, compare predictive models, evaluate subgroup performance, communicate results visually, and consider ethics and operational deployment.

The repository is intentionally reproducible and software-oriented, with Python, SQL, Jupyter, SQLite, a Streamlit dashboard, model evaluation artifacts, and documentation. It demonstrates preparation relevant to graduate study in data mining, data analysis and visualization, data ethics, machine learning, and database development.
