# Data Dictionary

| Field | Type | Description |
|---|---|---|
| encounter_id | string | Synthetic unique encounter identifier |
| age | integer | Patient age at encounter |
| sex | category | Synthetic sex category |
| race_ethnicity | category | Synthetic demographic category |
| insurance | category | Primary insurance category |
| primary_condition | category | Main clinical service/condition grouping |
| ed_visits_12mo | integer | ED visits in prior 12 months |
| prior_admissions_12mo | integer | Admissions in prior 12 months |
| comorbidity_count | integer | Synthetic count of chronic conditions |
| length_of_stay_days | float | Encounter length of stay |
| discharge_disposition | category | Discharge destination |
| followup_status | category | Whether post-discharge follow-up was completed |
| 30_day_readmission | binary | Synthetic target: readmitted within 30 days |
