# 🏥 Healthcare Readmission & Patient Risk Analytics

**End-to-end healthcare data science portfolio project using synthetic encounter data.**

## Executive question
Can routinely available encounter-level information help identify patients at elevated risk of 30-day hospital readmission while responsibly evaluating subgroup performance?

## What this demonstrates
**Healthcare question → data quality → SQL/KPIs → EDA → machine learning → model comparison → fairness audit → dashboard → operational recommendation**

### Technical stack
Python • pandas • NumPy • scikit-learn • SQL/SQLite • Jupyter • Streamlit • Matplotlib • Git/GitHub

### Dataset
**12,000 synthetic encounters. No PHI.**

### Key findings
- Overall synthetic readmission rate: **28.8%**
- Average length of stay: **4.73 days**
- Highest-readmission condition: **Orthopedics (30.5%)**
- Best model by ROC-AUC: **Logistic Regression (0.664)**

## Model comparison
| Model               |   ROC-AUC |   Accuracy |   Precision |   Recall |    F1 |
|:--------------------|----------:|-----------:|------------:|---------:|------:|
| Logistic Regression |     0.664 |      0.629 |       0.401 |    0.583 | 0.475 |
| Gradient Boosting   |     0.656 |      0.713 |       0.505 |    0.117 | 0.19  |
| Random Forest       |     0.647 |      0.658 |       0.42  |    0.492 | 0.453 |

## Dashboard
Run:
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Repository
```text
├── app.py
├── README.md
├── requirements.txt
├── data/
│   ├── synthetic_encounters.csv
│   ├── healthcare_analytics.sqlite
│   └── DATA_DICTIONARY.md
├── notebooks/
│   └── 01_readmission_analysis.ipynb
├── sql/
│   ├── 01_quality_and_summary.sql
│   └── 02_operational_dashboard.sql
├── src/
│   └── analysis.py
└── reports/
    ├── academic_report.md
    ├── executive_summary.md
    ├── model_comparison.csv
    ├── subgroup_recall.csv
    ├── test_set_predictions.csv
    ├── resume_bullets.md
    ├── msds_application_project_framing.md
    └── figures/
```

## Fairness & responsible AI
Model recall is audited across sex, race/ethnicity, and insurance. The proposed use is **human-in-the-loop prioritization**, not autonomous clinical decision-making.

A production implementation would require clinical validation, prospective testing, privacy/security controls, calibration, subgroup monitoring, drift monitoring, and governance.

## Limitations
This is a portfolio project using synthetic data. It does not establish clinical validity or causality and should not be used for patient care.

## Why this fits UArizona MSDS
The project demonstrates data manipulation, analysis, visualization, predictive modeling, ethics, reproducibility, and software development. It is intentionally structured as a GitHub-hosted portfolio artifact that mirrors the kinds of competencies emphasized by UArizona's MSDS curriculum and capstone.
