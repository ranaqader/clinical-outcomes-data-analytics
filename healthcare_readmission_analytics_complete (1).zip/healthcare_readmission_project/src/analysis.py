import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    roc_auc_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "synthetic_encounters.csv")

# -----------------------
# 1. Data quality checks
# -----------------------
assert df["encounter_id"].is_unique
assert df["30_day_readmission"].isin([0, 1]).all()
assert df["age"].between(18, 95).all()

# -----------------------
# 2. Descriptive KPIs
# -----------------------
print("Overall readmission rate:", round(df["30_day_readmission"].mean(), 3))
print("Average LOS:", round(df["length_of_stay_days"].mean(), 2))

for col in ["primary_condition", "insurance", "followup_status", "discharge_disposition"]:
    summary = (
        df.groupby(col)["30_day_readmission"]
        .agg(["count", "mean"])
        .rename(columns={"count":"encounters", "mean":"readmission_rate"})
        .sort_values("readmission_rate", ascending=False)
    )
    print(f"\n--- {col} ---")
    print(summary)

# -----------------------
# 3. Modeling
# -----------------------
target = "30_day_readmission"
features = [
    "age", "sex", "race_ethnicity", "insurance", "primary_condition",
    "ed_visits_12mo", "prior_admissions_12mo", "comorbidity_count",
    "length_of_stay_days", "discharge_disposition", "followup_status"
]

X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

numeric = [
    "age", "ed_visits_12mo", "prior_admissions_12mo",
    "comorbidity_count", "length_of_stay_days"
]
categorical = [
    "sex", "race_ethnicity", "insurance", "primary_condition",
    "discharge_disposition", "followup_status"
]

preprocess = ColumnTransformer([
    ("num", Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale", StandardScaler())
    ]), numeric),
    ("cat", Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ]), categorical)
])

model = Pipeline([
    ("prep", preprocess),
    ("model", LogisticRegression(max_iter=2000, class_weight="balanced"))
])

model.fit(X_train, y_train)
pred_prob = model.predict_proba(X_test)[:, 1]
pred = (pred_prob >= 0.50).astype(int)

print("\n=== MODEL PERFORMANCE ===")
print("ROC-AUC:", round(roc_auc_score(y_test, pred_prob), 3))
print("Precision:", round(precision_score(y_test, pred), 3))
print("Recall:", round(recall_score(y_test, pred), 3))
print("F1:", round(f1_score(y_test, pred), 3))
print("\nConfusion matrix:")
print(confusion_matrix(y_test, pred))

# -----------------------
# 4. Simple subgroup check
# -----------------------
test = X_test.copy()
test["actual"] = y_test.values
test["pred_prob"] = pred_prob
test["pred"] = pred

print("\n=== SUBGROUP RECALL ===")
for group in ["sex", "race_ethnicity", "insurance"]:
    rows = []
    for name, g in test.groupby(group):
        if g["actual"].sum() > 0:
            rows.append({
                group: name,
                "n": len(g),
                "readmission_rate": g["actual"].mean(),
                "recall": recall_score(g["actual"], g["pred"])
            })
    print(pd.DataFrame(rows).sort_values("recall"))

# This is an educational project, not a clinical validation.
